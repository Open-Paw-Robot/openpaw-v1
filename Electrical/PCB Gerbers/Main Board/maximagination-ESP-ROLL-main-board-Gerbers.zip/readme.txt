Project Name: Ball Bot
Project Version: #dc2e079a
Project Url: https://www.flux.ai/maximagination/ball-bot

Project Description:
Welcome to your new project. Imagine what you can build here.

Project Properties:

Designator Prefix:
P

Part Type:
Terminal

Terminal Type:
passive

Terminal Order:


Symbol Pin Position:
[object Object]

Pin Number:
2

Pin Type:
Unspecified


